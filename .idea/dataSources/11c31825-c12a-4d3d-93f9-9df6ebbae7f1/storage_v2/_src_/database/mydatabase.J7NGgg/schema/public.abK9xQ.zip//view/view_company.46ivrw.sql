create view view_company
            (id, name, code, parent, parent_code, level_perusahaan, total_department, total_division, total_employee,
             type) as
SELECT c.id,
       c.name,
       c.code,
       cp.name                               AS parent,
       cp.code                               AS parent_code,
       c.level_perusahaan::integer           AS level_perusahaan,
       count(DISTINCT oh.bagian)::integer    AS total_department,
       count(DISTINCT oh.divisi_id)::integer AS total_division,
       count(uh.*)::integer                  AS total_employee,
       CASE
           WHEN cp.name IS NULL THEN 'Holding'::text
           ELSE 'Child'::text
           END                               AS type
FROM company c
         LEFT JOIN organization_holding oh ON c.code::text = oh.com_id::text
         LEFT JOIN user_holding uh ON uh.company_id::text = c.code::text
         LEFT JOIN company cp ON cp.id_perusahaan::text = c.parent_id_perusahaan::text
GROUP BY c.id, c.name, cp.name, cp.code, c.level_perusahaan;

alter table view_company
    owner to myuser;

